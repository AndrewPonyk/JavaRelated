package pack;

public class HelloFromMyModule {
	public static void say(){
		System.out.println("Hello");
	}
}	
