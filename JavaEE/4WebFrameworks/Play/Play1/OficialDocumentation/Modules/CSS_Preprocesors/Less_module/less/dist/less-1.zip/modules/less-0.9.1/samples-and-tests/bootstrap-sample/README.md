Play LESS module with Twitter Bootstrap Sample
==============================================

This is a sample application that has the Less version of Twitter bootstrap in `/public`, which is compiled into CSS by the Less module.

Usage
-----

 * Run `play dependencies` to fetch the Less module
 * Run `play run` to start the app
 * Surf to http://localhost:9000/ for Bootstrap goodness!

