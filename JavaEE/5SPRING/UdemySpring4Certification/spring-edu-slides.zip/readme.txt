Please find the related slides used(spring edu slides.zip) in this udemy course in this zip file.

You should download apache open office (free program) in order to open slides correctly with the extension of .odp

https://www.openoffice.org/download/index.html