package spring.jdbc.transactions.orm;

public class DBLog {
	
	private int IDLOG;
	private String LOGSTRING;
	
	public int getIDLOG() {
		return IDLOG;
	}
	public void setIDLOG(int iDLOG) {
		IDLOG = iDLOG;
	}
	public String getLOGSTRING() {
		return LOGSTRING;
	}
	public void setLOGSTRING(String lOGSTRING) {
		LOGSTRING = lOGSTRING;
	}
	
	
	

}
