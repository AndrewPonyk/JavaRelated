package spring.bean;

public class ComplexBean {

	@Override
	public String toString() {
		return "Complex Bean Returned";
	}
}
