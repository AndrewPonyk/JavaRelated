package spring.jdbc.transactions.orm;

public interface Log {
	public boolean log(String log);
}

