package spring.bean;

public interface Log {
	public boolean log(String log);
}

