# customer-api

A very simple Spring Boot REST API, performs CRUD operations on a SQLite database, documented with Swagger2.

* Swagger UI URL: http://localhost:8080/customer-api/swagger-ui/

* Swagger JSON URL: http://localhost:8080/customer-api/v2/api-docs


